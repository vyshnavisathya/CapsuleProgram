package com.fse.cognizant.taskmanager.repository;

import com.fse.cognizant.taskmanager.dao.ParentTask;
import org.springframework.data.repository.CrudRepository;

public interface ParentTaskRepository extends CrudRepository<ParentTask, Integer> {

}

import { ParentTask } from './parent-task.model';

describe('ParentTask', () => {
  it('should create an instance', () => {
    expect(new ParentTask()).toBeTruthy();
  });
});
 
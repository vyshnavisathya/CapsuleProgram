export class Task{

    taskId: number;
	taskName: string;
	parentTask: boolean;
	projectName: string;
	startDate: string;
	endDate: string;
	parentTaskName: string;
	parentTaskId: number;
	projectId: number;
	userName: string;
	userId: number;
	priority: number;
	status: string;

}
 